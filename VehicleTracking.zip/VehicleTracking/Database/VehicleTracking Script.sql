CREATE DATABASE VehicleTracking;
GO

USE VehicleTracking;
GO

IF SCHEMA_ID(N'Tracker') IS NULL EXEC(N'CREATE SCHEMA [Tracker];');
GO


IF SCHEMA_ID(N'Vehicle') IS NULL EXEC(N'CREATE SCHEMA [Vehicle];');
GO


CREATE TABLE [Vehicle].[tblVehicle] (
    [VehicleId] INT NOT NULL IDENTITY,
    [VehicleRegNo] VARCHAR(20) NOT NULL,
    [TrackingDeviceId] VARCHAR(100) NOT NULL,
    [RegisterStamp] DATETIME NOT NULL,
    [Model] VARCHAR(10),
    CONSTRAINT [PK_tblVehicle] PRIMARY KEY ([VehicleId])
);
GO


CREATE TABLE [Tracker].[tblPosition] (
    [PositionId] BIGINT NOT NULL IDENTITY,
    [VehicleId] INT NOT NULL,
    [TrackingDeviceId] VARCHAR(100) NULL,
    [Longitude] DECIMAL(11,8) NOT NULL,
    [Latitude] DECIMAL(11,8) NOT NULL,
    [TrackStamp] DATETIME NOT NULL,
    CONSTRAINT [PK_tblPosition] PRIMARY KEY ([PositionId]),
    CONSTRAINT [FK_tblPosition_tblVehicle_VehicleId] FOREIGN KEY ([VehicleId]) REFERENCES [Vehicle].[tblVehicle] ([VehicleId]) ON DELETE CASCADE
);
GO


CREATE INDEX [IX_tblPosition_VehicleId] ON [Tracker].[tblPosition] ([VehicleId]);
GO


CREATE UNIQUE INDEX [IX_tblVehicle_TrackingDeviceId] ON [Vehicle].[tblVehicle] ([TrackingDeviceId]);
GO


CREATE UNIQUE INDEX [IX_tblVehicle_VehicleRegNo] ON [Vehicle].[tblVehicle] ([VehicleRegNo]);
GO

CREATE PROCEDURE Vehicle.spAddNewVehicle
    @VehicleRegNo VARCHAR(20), 
    @TrackingDeviceId VARCHAR(100), 
    @Model VARCHAR(50),
    @spReturn INT OUT
AS
BEGIN
	SET @spReturn = -99;

	IF @VehicleRegNo IS NULL
		SET @spReturn = -1;

	IF @TrackingDeviceId IS NULL
		SET @spReturn = -2;

	IF EXISTS (SELECT 1 FROM Vehicle.tblVehicle WITH(NOLOCK) WHERE VehicleRegNo = @VehicleRegNo)
		SET @spReturn = -3;

	IF EXISTS (SELECT 1 FROM Vehicle.tblVehicle WITH(NOLOCK) WHERE TrackingDeviceId = @TrackingDeviceId)
		SET @spReturn = -4;

	INSERT INTO Vehicle.tblVehicle (VehicleRegNo, TrackingDeviceId, RegisterStamp, Model)
	VALUES (@VehicleRegNo, @TrackingDeviceId, GETDATE(), @Model);

	IF @@ROWCOUNT = 1
		SET @spReturn = 0;
END;
GO

CREATE PROCEDURE Vehicle.spGetVehicleDetails
    @VehicleRegNo VARCHAR(20)
AS
BEGIN
	SELECT [VehicleId],
		[VehicleRegNo],
		[TrackingDeviceId],
		[RegisterStamp],
		[Model] 
	FROM Vehicle.tblVehicle WITH (NOLOCK) 
	WHERE VehicleRegNo = @VehicleRegNo
END;  
GO


CREATE PROCEDURE Tracker.spGetLastPositionDetails
    @VehicleId INT
AS
BEGIN
	SELECT	[PositionId],
			[VehicleId],
			[TrackingDeviceId],
			[Longitude],
			[Latitude],
			[TrackStamp]
	FROM Tracker.tblPosition WITH(NOLOCK)
	WHERE VehicleId = @VehicleId 
	ORDER BY TrackStamp DESC
END;
GO


CREATE PROCEDURE Tracker.spAddNewPosition
    @VehicleId INT, 
	@TrackingDeviceId VARCHAR(100),
    @Longitude DECIMAL(11,8), 
    @Latitude DECIMAL(11,8), 
    @TrackStamp VARCHAR(50), 
    @spReturn INT OUT
AS
BEGIN
	SET @spReturn = -99;

	IF @VehicleId IS NULL
		SET @spReturn = -7;

	IF @TrackingDeviceId IS NULL
		SET @spReturn = -2;

	IF EXISTS (SELECT 1 FROM Vehicle.tblVehicle WITH(NOLOCK) WHERE VehicleId = @VehicleId)
		SET @spReturn = -3; 

	IF NOT EXISTS (SELECT 1 FROM Vehicle.tblVehicle WITH(NOLOCK) WHERE VehicleId = @VehicleId 
	AND TrackingDeviceId = @TrackingDeviceId)
		SET @spReturn = -5; 

	DECLARE @LastTrackStamp DATETIME
	EXECUTE @LastTrackStamp = Tracker.spGetLastPositionDetails @VehicleId

	IF @LastTrackStamp > @TrackStamp
		SET @spReturn = -6

	INSERT INTO Tracker.tblPosition(VehicleId, TrackingDeviceId, Longitude, Latitude, TrackStamp)
	VALUES (@VehicleId, @TrackingDeviceId, @Longitude, @Latitude, @TrackStamp)

	IF @@ROWCOUNT = 1
		SET @spReturn = 0
END;  
GO


CREATE PROCEDURE Tracker.spGetPositionByTimeRange
    @VehicleId INT, 
    @Start DATETIME = NULL,
	@End DATETIME = NULL
AS
BEGIN

	IF @Start IS NULL
		SET @Start = DATEADD(day, -30, GETDATE())

	IF @End IS NULL
		SET @End = GETDATE()

	SELECT	[PositionId],
			[VehicleId],
			[TrackingDeviceId],
			[Longitude],
			[Latitude],
			[TrackStamp]
	FROM Tracker.tblPosition WITH(NOLOCK)
	WHERE VehicleId = @VehicleId 
			AND TrackStamp > @Start 
			AND TrackStamp < @End
END;
GO