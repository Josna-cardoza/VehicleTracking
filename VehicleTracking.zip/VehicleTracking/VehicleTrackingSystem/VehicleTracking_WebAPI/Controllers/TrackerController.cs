﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VehicleTracking_Domain.Models;
using VehicleTracking_Service.svcPosition;

namespace VehicleTracking_WebAPI.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class TrackerController : ControllerBase
    {
        private readonly IPositionService positionService;

        public TrackerController(IPositionService _positionService)
        {
            positionService = _positionService;
        }

        [HttpGet(template: "CurrentPosition/{vehicleId}")]
        public async Task<IActionResult> GetLastPosition(int vehicleId)
        {
            return Ok(await positionService.GetLastPositionAsync(vehicleId));
        }

        [HttpGet(template: "GetPositionsByTime/{vehicleId}/{fromDateTime}/{toDateTime}")]
        public async Task<IActionResult> GetJourneyPositions(int vehicleId, string fromDateTime, string toDateTime)
        {
            return Ok(await positionService.GetJourneyPositionsAsync(vehicleId, fromDateTime, toDateTime));
        }

        [HttpPost(template: "UpdatePosition")]
        public async Task<IActionResult> RecordPosition(Position position)
        {
            return Ok(await positionService.RecordPositionAsync(position));
        }
    }
}
