﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VehicleTracking_Domain.Models;
using VehicleTracking_Service.svcVehicle;

namespace VehicleTracking_WebAPI.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class VehicleController : ControllerBase
    {
        private readonly IVehicleService vehicleService;

        public VehicleController(IVehicleService _vehicleService)
        {
            vehicleService = _vehicleService;
        }

        [HttpGet(template: "GetVehicleDetails/{vehicleRegNo}")]
        public async Task<IActionResult> GetVehicle(string vehicleRegNo)
        {
            return Ok(await vehicleService.GetVehicleAsync(vehicleRegNo));
        }

        [HttpPost(template: "Register")]
        public async Task<IActionResult> RegisterVehicle(Vehicle vehicle)
        {
            return Ok(await vehicleService.RegisterVehicleAsync(vehicle));
        }
    }
}
