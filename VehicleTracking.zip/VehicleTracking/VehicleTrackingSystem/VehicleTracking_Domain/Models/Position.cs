﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;

namespace VehicleTracking_Domain.Models
{
    public class Position
    {
        public long PositionId { get; set; }
        public int VehicleId { get; set; }
        public string TrackingDeviceId { get; set; }
        public decimal Longitude { get; set; }
        public decimal Latitude { get; set; }
        public DateTime TrackStamp { get; set; }

        [JsonIgnore]
        public Vehicle Vehicle { get; set; }

        public string GetString()
        {
            return Newtonsoft.Json.JsonConvert.SerializeObject(this);
        }
    }
}
