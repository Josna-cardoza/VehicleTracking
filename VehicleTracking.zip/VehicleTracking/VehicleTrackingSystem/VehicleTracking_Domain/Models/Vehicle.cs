﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;

namespace VehicleTracking_Domain.Models
{
    public class Vehicle
    {
        public int VehicleId { get; set; }
        public string VehicleRegNo { get; set; }
        public string TrackingDeviceId { get; set; }
        public DateTime RegisterStamp { get; set; }
        public string Model { get; set; }

        [JsonIgnore]
        public ICollection<Position> Positions { get; set; }

        public string GetString()
        {
            return Newtonsoft.Json.JsonConvert.SerializeObject(this);
        }
    }
}
