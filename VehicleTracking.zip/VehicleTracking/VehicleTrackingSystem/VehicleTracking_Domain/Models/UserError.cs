﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VehicleTracking_Domain.Models
{
    public class UserError
    {
        public int ErrorCode { get; set; }
        public string ErrorMessage { get; set; }
    }
}
