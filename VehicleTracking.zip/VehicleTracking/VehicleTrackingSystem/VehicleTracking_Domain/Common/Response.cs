﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VehicleTracking_Domain.Common
{
    public class Response<T>
    {
        public Response()
        {
        }
        public Response(T data, string message = null)
        {
            Succeeded = true;
            Message = message;
            Data = data;
        }

        public Response(int errorCode, string message, LogData logData = null)
        {
            Succeeded = false;
            ErrorCode = errorCode;
            Message = message;
            LogError(errorCode, message, logData);
        }

        private void LogError(int errorCode, string message, LogData logData)
        {
            logData.Log(errorCode, message);
        }

        public bool Succeeded { get; set; }
        public int ErrorCode { get; set; }
        public string Message { get; set; }
        public T Data { get; set; }
    }
}
