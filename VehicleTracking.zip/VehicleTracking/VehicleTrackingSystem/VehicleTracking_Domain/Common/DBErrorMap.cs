﻿using System;
using System.Collections.Generic;
using System.Text;
using VehicleTracking_Domain.Models;

namespace VehicleTracking_Domain.Common
{
    public static class DBErrorMap
    {
        public static UserError GetUserError(int dbErrorCode)
        {
            UserError userError = new UserError();

            switch (dbErrorCode)
            {
                case -1:
                    //Here Error Code and Message can be fetched from file or table.
                    userError.ErrorCode = 2001;
                    userError.ErrorMessage = "Invalid vehicle no.";
                    break;
                case -2:
                    userError.ErrorCode = 2002;
                    userError.ErrorMessage = "Invalid Tracking device";
                    break;
                case -3:
                    userError.ErrorCode = 2003;
                    userError.ErrorMessage = "This vehicle is not registered with us";
                    break;
                case -4:
                    userError.ErrorCode = 2004;
                    userError.ErrorMessage = "Unable to perform operation. Tracking device is not mapped to this vehicle.";
                    break;
                case -5:
                    userError.ErrorCode = 2005;
                    userError.ErrorMessage = "This vehicle is not registered with us";
                    break;
                case -6:
                    userError.ErrorCode = 2006;
                    userError.ErrorMessage = "Time of update can not be before the last position update.";
                    break;
                case -7:
                    userError.ErrorCode = 2007;
                    userError.ErrorMessage = "Invalid vehicle ID";
                    break;
                default:
                    userError.ErrorCode = 2999;
                    userError.ErrorMessage = "Something went wrong!";
                    break;
            }

            return userError;
        }
    }
}
