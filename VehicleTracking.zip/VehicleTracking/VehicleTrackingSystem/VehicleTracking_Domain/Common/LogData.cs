﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace VehicleTracking_Domain.Common
{
    public class LogData
    {
        public string AssemblyName { get; set; }
        public string ApiName { get; set; }
        public string FunctionName { get; set; }
        public string Details { get; set; }

        public void Log(int errorCode, string message)
        {
            try
            {
                if (!Directory.Exists("logs"))
                {
                    Directory.CreateDirectory("logs");
                }
                using (StreamWriter writetext = new StreamWriter("logs/" + DateTime.Now.ToString("yyyyMMdd") + ".txt",
                    append: true))
                {
                    JObject obj = this.Details == null ? new JObject() : JObject.Parse(this.Details);
                    obj.Add("ErrorCode", errorCode);
                    obj.Add("Message", message);
                    obj.Add("LogDate", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff"));
                    writetext.WriteLine(obj);
                }
            }
            catch (Exception ex)
            { }
        }
    }
}
