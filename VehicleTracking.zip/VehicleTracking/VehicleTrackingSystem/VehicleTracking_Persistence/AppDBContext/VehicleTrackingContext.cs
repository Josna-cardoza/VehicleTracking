﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using VehicleTracking_Domain.Encryption;
using VehicleTracking_Domain.Models;

namespace VehicleTracking_Persistence.AppDBContext
{
    public partial class VehicleTrackingContext : DbContext
    {
        private readonly IConfiguration configuration;

        public VehicleTrackingContext()
        {

        }

        public VehicleTrackingContext(DbContextOptions<VehicleTrackingContext> options,
            IConfiguration _configuration
            ) : base(options)
        {
            configuration = _configuration;
        }

        public DbSet<Vehicle> Vehicles { get; set; }
        public DbSet<Position> Positions { get; set; }

        public async Task<int> SaveChangesAsync()
        {
            return await base.SaveChangesAsync();
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(AesOperation.DecryptString(configuration["Encrypt:Key"], configuration.GetConnectionString("VTSDBConnection")));
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

            modelBuilder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly());

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
