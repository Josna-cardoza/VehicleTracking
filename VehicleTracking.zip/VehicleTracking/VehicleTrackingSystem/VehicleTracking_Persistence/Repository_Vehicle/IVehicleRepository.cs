﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using VehicleTracking_Domain.Models;

namespace VehicleTracking_Persistence.Repository_Vehicle
{
    public interface IVehicleRepository
    {
        Task<int> Insert(Vehicle vehicle);
        Task<Vehicle> GetVehicleAsync(string vehicleRegNo);
    }
}
