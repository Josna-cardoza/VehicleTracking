﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;
using VehicleTracking_Domain.Models;
using VehicleTracking_Persistence.AppDBContext;

namespace VehicleTracking_Persistence.Repository_Vehicle
{
    public class VehicleRepository : IVehicleRepository
    {
        private readonly VehicleTrackingContext dbContext;

        public VehicleRepository(VehicleTrackingContext _appcontext)
        {
            dbContext = _appcontext;
        }

        public async Task<Vehicle> GetVehicleAsync(string vehicleRegNo)
        {
            Vehicle vehicle = new Vehicle();

            if (dbContext != null)
            {
                var data = await dbContext.Vehicles.FromSqlRaw(@"Vehicle.spGetVehicleDetails
                @VehicleRegNo",
                new SqlParameter("VehicleRegNo", vehicleRegNo)).ToListAsync();
                vehicle = data.Find(v => v.VehicleRegNo == vehicleRegNo);
            }
            return vehicle;
        }

        public async Task<int> Insert(Vehicle vehicle)
        {
            var returnValue = new SqlParameter("@spReturn", SqlDbType.Int);
            returnValue.Direction = ParameterDirection.Output;

            if (dbContext != null)
            {
                await dbContext.Database.ExecuteSqlRawAsync(@"Vehicle.spAddNewVehicle
                @VehicleRegNo, 
                @TrackingDeviceId,
                @Model, 
                @spReturn out",
                new SqlParameter("VehicleRegNo", vehicle.VehicleRegNo),
                new SqlParameter("TrackingDeviceId", vehicle.TrackingDeviceId),
                new SqlParameter("Model", vehicle.Model),
                returnValue);
            }
            return Convert.ToInt32(returnValue.Value);
        }
    }
}
