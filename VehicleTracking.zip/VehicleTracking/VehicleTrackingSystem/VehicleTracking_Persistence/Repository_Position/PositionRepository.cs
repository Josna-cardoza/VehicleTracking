﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;
using VehicleTracking_Domain.Models;
using VehicleTracking_Persistence.AppDBContext;

namespace VehicleTracking_Persistence.Repository_Position
{
    public class PositionRepository : IPositionRepository
    {
        private readonly VehicleTrackingContext dbContext;

        public PositionRepository(VehicleTrackingContext _appcontext)
        {
            dbContext = _appcontext;
        }

        public async Task<List<Position>> GetPositionByTimeRange(int vehicleId, DateTime? start, DateTime? end)
        {
            List<Position> data = new List<Position>();

            object objStart, objEnd;

            if (start is null)
                objStart = DBNull.Value;
            else
                objStart = start;

            if (end is null)
                objEnd = DBNull.Value;
            else
                objEnd = end;

            if (dbContext != null)
            {
                data = await dbContext.Positions.FromSqlRaw(@"Tracker.spGetPositionByTimeRange
                @VehicleId, 
                @Start, 
                @End",
                new SqlParameter("VehicleId", vehicleId),
                new SqlParameter("Start", start),
                new SqlParameter("End", objEnd)).ToListAsync();
            }
            return data;
        }

        public async Task<Position> GetLastPositionDetails(int vehicleId)
        {
            Position position = new Position();

            if (dbContext != null)
            {
                var data = await dbContext.Positions.FromSqlRaw(@"Tracker.spGetLastPositionDetails
                @VehicleId",
                new SqlParameter("VehicleId", vehicleId)).ToListAsync();

                position = data.Find(p => p.VehicleId == vehicleId);
            }
            return position;
        }

        public async Task<int> Insert(Position position)
        {
            var returnValue = new SqlParameter("@spReturn", SqlDbType.Int);
            returnValue.Direction = ParameterDirection.Output;

            if (dbContext != null)
            {
                await dbContext.Database.ExecuteSqlRawAsync(@"Tracker.spAddNewPosition
                @VehicleId, 
                @TrackingDeviceId,
                @Longitude, 
                @Latitude, 
                @TrackStamp, 
                @spReturn out",
                new SqlParameter("VehicleId", position.VehicleId),
                new SqlParameter("TrackingDeviceId", position.TrackingDeviceId),
                new SqlParameter("Longitude", position.Longitude),
                new SqlParameter("Latitude", position.Latitude),
                new SqlParameter("TrackStamp", position.TrackStamp),
                returnValue);
            }
            return Convert.ToInt32(returnValue.Value);
        }
    }
}
