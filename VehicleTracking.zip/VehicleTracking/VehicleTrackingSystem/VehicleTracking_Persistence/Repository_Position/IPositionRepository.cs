﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using VehicleTracking_Domain.Models;

namespace VehicleTracking_Persistence.Repository_Position
{
    public interface IPositionRepository
    {
        Task<int> Insert(Position position);
        Task<Position> GetLastPositionDetails(int vehicleId);
        Task<List<Position>> GetPositionByTimeRange(int vehicleId, DateTime? start, DateTime? end);
    }
}
