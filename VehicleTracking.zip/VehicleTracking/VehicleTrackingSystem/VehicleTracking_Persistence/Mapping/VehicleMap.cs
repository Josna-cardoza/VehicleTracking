﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;
using VehicleTracking_Domain.Models;

namespace VehicleTracking_Persistence.Mapping
{
    public class VehicleMap : IEntityTypeConfiguration<Vehicle>
    {
        public void Configure(EntityTypeBuilder<Vehicle> builder)
        {
            builder.HasKey(e => e.VehicleId);

            builder.ToTable("tblVehicle", "Vehicle");

            builder.HasIndex(e => e.VehicleRegNo)
                .IsUnique();

            builder.HasIndex(e => e.TrackingDeviceId)
               .IsUnique();

            builder.HasMany<Position>(p => p.Positions)
                .WithOne(v => v.Vehicle)
                .HasForeignKey(v => v.VehicleId);

            builder.Property(e => e.VehicleId)
                .HasColumnType("INT")
                .HasColumnName("VehicleId");

            builder.Property(e => e.VehicleRegNo)
                .IsRequired()
                .HasColumnType("VARCHAR")
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("VehicleRegNo");

            builder.Property(e => e.TrackingDeviceId)
                .IsRequired()
                .HasColumnType("VARCHAR")
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("TrackingDeviceId");

            builder.Property(e => e.Model)
                .HasColumnType("VARCHAR")
                .HasMaxLength(10)
                .IsUnicode(false);

            builder.Property(e => e.RegisterStamp)
                .HasColumnType("DATETIME")
                .HasColumnName("RegisterStamp");
        }
    }
}
