﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;
using VehicleTracking_Domain.Models;

namespace VehicleTracking_Persistence.Mapping
{
    public class PositionMap : IEntityTypeConfiguration<Position>
    {
        public void Configure(EntityTypeBuilder<Position> builder)
        {
            builder.HasKey(e => e.PositionId);

            builder.ToTable("tblPosition", "Tracker");

            builder.HasOne<Vehicle>(v => v.Vehicle)
                .WithMany(p => p.Positions)
                .HasForeignKey(p => p.VehicleId);

            builder.Property(e => e.PositionId)
                .HasColumnType("BIGINT")
                .HasColumnName("PositionId");

            builder.Property(e => e.VehicleId)
                .IsRequired()
                .HasColumnType("INT")
                .HasColumnName("VehicleId");

            builder.Property(e => e.Longitude)
                .IsRequired()
                .HasColumnType("DECIMAL")
                .HasPrecision(11, 8);

            builder.Property(e => e.Latitude)
                .IsRequired()
                .HasColumnType("DECIMAL")
                .HasPrecision(11, 8);

            builder.Property(e => e.TrackingDeviceId)
                .IsRequired()
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnType("VARCHAR")
                .HasColumnName("TrackingDeviceId");

            builder.Property(e => e.TrackStamp)
                .HasColumnType("DATETIME")
                .HasColumnName("TrackStamp");
        }
    }
}
