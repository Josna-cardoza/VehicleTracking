﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using VehicleTracking_Domain.Common;
using VehicleTracking_Domain.Models;
using VehicleTracking_Persistence.Repository_Vehicle;

namespace VehicleTracking_Service.svcVehicle
{
    public class VehicleService : IVehicleService
    {
        private readonly IVehicleRepository vehicleRepository;

        public VehicleService(IVehicleRepository _vehicleRepository)
        {
            vehicleRepository = _vehicleRepository;
        }

        public async Task<Response<Vehicle>> GetVehicleAsync(string vehicleRegNo)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(vehicleRegNo))
                {
                    return new Response<Vehicle>
                            (1001, $"Invalid Vehicle No.", new LogData
                            {
                                AssemblyName = "VehicleTracking_WebAPI",
                                ApiName = "/Vehicle/GetVehicleDetails/{vehicleRegNo}/",
                                FunctionName = "GetVehicleAsync",
                                Details = "{\"VEHICLEREGNO\": \"" + vehicleRegNo.ToString() + "\" }"
                            });
                }

                var vehicle = await vehicleRepository.GetVehicleAsync(vehicleRegNo);

                if (vehicle is null)
                    return new Response<Vehicle>(vehicle, $"Vehicle no. {vehicleRegNo} is not registered with us.");

                return new Response<Vehicle>(vehicle, $"Vehicle details retrieved Successfully");
            }
            catch (Exception ex)
            {
                return new Response<Vehicle>
                           (-9999, $"Something is not right here.", new LogData
                           {
                               AssemblyName = "VehicleTracking_WebAPI",
                               ApiName = "/Vehicle/GetVehicleDetails/{vehicleRegNo}/",
                               FunctionName = "GetVehicleAsync",
                               Details = "{ \"EX\":\"" + ex.ToString() + "\" }"
                           });
            }
        }

        public async Task<Response<Vehicle>> RegisterVehicleAsync(Vehicle vehicle)
        {
            try
            {
                if (vehicle is null ||
                    string.IsNullOrWhiteSpace(vehicle.TrackingDeviceId) ||
                    string.IsNullOrWhiteSpace(vehicle.VehicleRegNo)
                    //Can add validation for specific format of vehicle no.
                    )
                {
                    return new Response<Vehicle>
                            (1002, $"Invalid input.", new LogData
                            {
                                AssemblyName = "VehicleTracking_WebAPI",
                                ApiName = "/Vehicle/Register/",
                                FunctionName = "RegisterVehicleAsync",
                                Details = "{\"VEHICLEREGNO\": \"" + vehicle.VehicleRegNo +
                                "\",\"TRACKINGDEVICEID\": \"" + vehicle.TrackingDeviceId + "\",\"MODEL\": \"" +
                                vehicle.Model + "\" }"
                            });
                }

                var spReturn = await vehicleRepository.Insert(vehicle);

                if (spReturn != 0)
                {
                    var userError = DBErrorMap.GetUserError(spReturn);

                    return new Response<Vehicle>
                            (userError.ErrorCode, userError.ErrorMessage, new LogData
                            {
                                AssemblyName = "VehicleTracking_WebAPI",
                                ApiName = "/Vehicle/Register/",
                                FunctionName = "RegisterVehicleAsync",
                                Details = "{\"SP Returned\": \"" + spReturn.ToString() + "\"}"
                            });
                }

                Vehicle retVehicle = await vehicleRepository.GetVehicleAsync(vehicle.VehicleRegNo);

                if (retVehicle is null)
                {
                    return new Response<Vehicle>(retVehicle, $"Vehicle Registered Successfully. " +
                        $"However, failed to retrieve the data.");
                }

                return new Response<Vehicle>(retVehicle, $"Vehicle Registered Successfully");

            }
            catch (Exception ex)
            {
                return new Response<Vehicle>
                           (-9999, $"Something is not right here.", new LogData
                           {
                               AssemblyName = "VehicleTracking_WebAPI",
                               ApiName = "/Vehicle/Register/",
                               FunctionName = "RegisterVehicleAsync",
                               Details = "{ \"EX\":\"" + ex.ToString() + "\" }"
                           });
            }

        }
    }
}
