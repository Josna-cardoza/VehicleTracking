﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using VehicleTracking_Domain.Common;
using VehicleTracking_Domain.Models;

namespace VehicleTracking_Service.svcVehicle
{
    public interface IVehicleService
    {
        Task<Response<Vehicle>> GetVehicleAsync(string vehicleRegNo);
        Task<Response<Vehicle>> RegisterVehicleAsync(Vehicle vehicle);
    }
}
