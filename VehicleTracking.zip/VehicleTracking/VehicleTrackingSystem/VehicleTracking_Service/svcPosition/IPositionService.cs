﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using VehicleTracking_Domain.Common;
using VehicleTracking_Domain.Models;

namespace VehicleTracking_Service.svcPosition
{
    public interface IPositionService
    {
        Task<Response<Position>> GetLastPositionAsync(int vehicleId);
        Task<Response<List<Position>>> GetJourneyPositionsAsync(int vehicleId, string fromDateTime, string toDateTime);
        Task<Response<bool>> RecordPositionAsync(Position position);
    }
}
