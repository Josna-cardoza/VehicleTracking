﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Threading.Tasks;
using VehicleTracking_Domain.Common;
using VehicleTracking_Domain.Models;
using VehicleTracking_Persistence.Repository_Position;

namespace VehicleTracking_Service.svcPosition
{
    public class PositionService : IPositionService
    {
        private readonly IPositionRepository positionRepository;

        public PositionService(IPositionRepository _positionRepository)
        {
            positionRepository = _positionRepository;
        }

        public async Task<Response<Position>> GetLastPositionAsync(int vehicleId)
        {
            try
            {
                if (vehicleId <= 0)
                {
                    return new Response<Position>
                            (1003, $"Invalid input", new LogData
                            {
                                AssemblyName = "VehicleTracking_WebAPI",
                                ApiName = "/Tracker/CurrentPosition/{vehicleId}/",
                                FunctionName = "GetLastPositionAsync",
                                Details = "{\"VEHICLEID\": \"" + vehicleId.ToString() + "\"}"
                            });
                }

                var position = await positionRepository.GetLastPositionDetails(vehicleId);

                if (position == null)
                    return new Response<Position>(position, $"Positions not recorded for this vehicle.");

                return new Response<Position>(position, $"Position retrieved Successfully");
            }
            catch (Exception ex)
            {
                return new Response<Position>
                            (-9999, $"Something is not right here.", new LogData
                            {
                                AssemblyName = "VehicleTracking_WebAPI",
                                ApiName = "/Tracker/CurrentPosition/{vehicleId}/",
                                FunctionName = "GetLastPositionAsync",
                                Details = "{\"Ex\":\"" + ex.ToString() + "\"}"
                            });
            }
        }

        public async Task<Response<List<Position>>> GetJourneyPositionsAsync(
            int vehicleId, string fromDateTime, string toDateTime)
        {
            try
            {
                DateTime? start = null;
                DateTime? end = null;

                if (vehicleId <= 0)
                {
                    return new Response<List<Position>>
                            (1004, $"Invalid input.", new LogData
                            {
                                AssemblyName = "VehicleTracking_WebAPI",
                                ApiName = "/Tracker/GetPositionsByTime/{vehicleId}/{fromDateTime}/{toDateTime}/",
                                FunctionName = "GetJourneyPositionsAsync",
                                Details = "{\"VEHICLEID\":\"" + vehicleId + "\",\"FROMDATETIME\": \"" + fromDateTime +
                                "\",\"TODATETIME\": \"" + toDateTime + "\"}"
                            }); ;
                }

                try
                {
                    start = DateTime.ParseExact(fromDateTime, "yyyy-MM-dd HH:mm",
                        CultureInfo.InvariantCulture, DateTimeStyles.None);
                    end = DateTime.ParseExact(toDateTime, "yyyy-MM-dd HH:mm",
                        CultureInfo.InvariantCulture, DateTimeStyles.None);
                }
                catch (Exception ex)
                {
                    return new Response<List<Position>>
                            (1005, $"Invalid input. Invalid date received", new LogData
                            {
                                AssemblyName = "VehicleTracking_WebAPI",
                                ApiName = "/Tracker/GetPositionsByTime/{vehicleId}/{fromDateTime}/{toDateTime}/",
                                FunctionName = "GetJourneyPositionsAsync",
                                Details = "{\"VEHICLEID\":\"" + vehicleId + "\",\"FROMDATETIME\": \"" + fromDateTime +
                                "\",\"TODATETIME\": \"" + toDateTime + "\",\"EX\": \"" + ex.ToString() + "\"}"
                            }); ;
                }

                var positions = await positionRepository.GetPositionByTimeRange(vehicleId, start, end);

                if (positions == null || positions.Count == 0)
                    return new Response<List<Position>>(positions, $"No data found for this vehicle.");

                return new Response<List<Position>>(positions, $"Data retrieved successfully");
            }
            catch (Exception ex)
            {
                return new Response<List<Position>>
                            (-9999, "Something is not right here.", new LogData
                            {
                                AssemblyName = "VehicleTracking_WebAPI",
                                ApiName = "/Tracker/GetPositionsByTime/{vehicleId}/{fromDateTime}/{toDateTime}/",
                                FunctionName = "GetJourneyPositionsAsync",
                                Details = "{ \"EX\":\"" + ex.ToString() + "\" }"
                            });
            }
        }

        public async Task<Response<bool>> RecordPositionAsync(Position position)
        {
            try
            {
                if (position is null ||
                    position.VehicleId < 0 ||
                    string.IsNullOrWhiteSpace(position.TrackingDeviceId) ||
                    position.Longitude <= 0 ||
                    position.Latitude <= 0
                    )
                {
                    return new Response<bool>
                            (1006, $"Invalid input", new LogData
                            {
                                AssemblyName = "VehicleTracking_WebAPI",
                                ApiName = "/Tracker/UpdatePosition/",
                                FunctionName = "RecordPositionAsync",
                                Details = position.GetString()
                            });
                }

                var spReturn = await positionRepository.Insert(position);

                if (spReturn != 0)
                {
                    var userError = DBErrorMap.GetUserError(spReturn);

                    return new Response<bool>
                            (userError.ErrorCode, userError.ErrorMessage, new LogData
                            {
                                AssemblyName = "VehicleTracking_WebAPI",
                                ApiName = "/Tracker/UpdatePosition/",
                                FunctionName = "RecordPositionAsync",
                                Details = "{\"SP Returned\": \"" + spReturn.ToString() + "\"}"
                            });
                }

                return new Response<bool>(true, $"Position Recorded Successfully");
            }
            catch (Exception ex)
            {
                return new Response<bool>
                            (-9999, "Something is not right here.", new LogData
                            {
                                AssemblyName = "VehicleTracking_WebAPI",
                                ApiName = "/Tracker/UpdatePosition/",
                                FunctionName = "RecordPositionAsync",
                                Details = "{ \"EX\":\"" + ex.ToString() + "\" }"
                            });
            }
        }
    }
}
